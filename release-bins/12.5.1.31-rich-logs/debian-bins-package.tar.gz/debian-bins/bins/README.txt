Debian 13 (trixie) rtpengine binaries
branch: rich-recording-debug-logs
commit: dcefb9cfb53949561ec3dc14630e66b6f62e10f0
built:  2026-08-07T07:40Z
image:  debian:trixie-slim (repo Dockerfile)

Install on siprec host:
  sudo cp rtpengine /usr/local/bin/   # or /usr/bin/
  sudo cp rtpengine-recording /usr/bin/
  sudo chmod 755 /usr/local/bin/rtpengine /usr/bin/rtpengine-recording

These are NOT the RHEL binaries. Do not mix with rhel/bins on Debian.
