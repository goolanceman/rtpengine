Canonical Debian bins from release-bins/12.5.1.31-rich-logs/debian
