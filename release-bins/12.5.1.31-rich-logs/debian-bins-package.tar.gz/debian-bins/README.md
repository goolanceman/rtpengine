See build-tools/BINS.md — bins live in release-bins/.../debian
