# rtpengine 12.5.1.31 rich-recording-logs — Debian userspace only

Branch: rich-recording-logs-12.5.1.31
Commit: dac32399
Version: 12.5.1.31+0~mr12.5.1.31

## Contents

- bins/rtpengine — daemon with human-friendly recording lifecycle logs
- bins/rtpengine-recording — recording-daemon with matching logs

**No kernel module** is included. Keep the host package module:

    rtpengine-kernel-dkms 12.5.1.31  ->  xt_RTPENGINE

Userspace and kernel must both be **12.5.x**. Do **not** mix with 26.x module.

## Install on Debian siprec (safe)

    cd debian-bins
    sudo bash install-on-debian-siprec.sh

Or manually:

    sudo systemctl stop rtpengine rtpengine-recording
    sudo cp -a $(which rtpengine) $(which rtpengine).pkg.bak
    sudo cp -a $(which rtpengine-recording) $(which rtpengine-recording).pkg.bak
    sudo install -m 755 bins/rtpengine $(which rtpengine)
    sudo install -m 755 bins/rtpengine-recording $(which rtpengine-recording)
    lsmod | grep -iE 'rtp|RTP'
    ls -la /proc/rtpengine/control
    sudo systemctl start rtpengine-recording rtpengine
    systemctl is-active rtpengine rtpengine-recording
    sudo journalctl -u rtpengine -u rtpengine-recording -n 50 --no-pager | grep recording

## Verify rich logs

After a recorded call you should see:

    recording DETECT ...
    recording START ...
    recording FILE status=CREATED type=proc-meta ...
    recording STREAM status=OPENED ...
    recording NEW ...
    recording FINISH ...
