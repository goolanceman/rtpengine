# rtpengine 11.5.1.24 rich recording + call QoS logs

See build-tools/BINS.md and build-tools/CONFLUENCE-11.5.1.24-rich-logs-usage.md

Canonical build outputs:
  Debian: build-tools/bins/debian/
  RHEL:   build-tools/bins/rhel/

Recording fix (83834a93): ignore RTPengine's synthetic NAT-piercing probe (PT 127,
sequence 65535, SSRC 0) instead of passing it to the audio decoder.

Promote on Debian siprec:
  BIN_DIR="$PWD/build-tools/bins/debian" \
    sudo -E bash build-tools/install-on-debian-siprec-userspace.sh promote

Promote on RHEL lab:
  BIN_DIR="$PWD/build-tools/bins/rhel" \
    sudo -E bash build-tools/install-on-debian-siprec-userspace.sh promote
