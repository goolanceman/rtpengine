# rtpengine 12.5.1.31 rich recording logs — deploy package

Contents:
- release-bins/12.5.1.31-rich-logs/debian/  (use on Debian siprec)
- release-bins/12.5.1.31-rich-logs/rhel/    (lab EL8 only)
- build-tools/install-on-debian-siprec-userspace.sh
- build-tools/fix-recording-bin-on-siprec.sh
- build-tools/side-by-side-test/
- build-tools/CONFLUENCE-12.5.1.31-rich-logs-usage.md

## Debian siprec (production promote)

    tar xzf rtpengine-12.5.1.31-rich-logs.tar.gz
    cd rtpengine-12.5.1.31-rich-logs

    sudo bash build-tools/install-on-debian-siprec-userspace.sh status
    sudo bash build-tools/install-on-debian-siprec-userspace.sh backup

    BIN_DIR="$PWD/release-bins/12.5.1.31-rich-logs/debian" \
      sudo -E bash build-tools/install-on-debian-siprec-userspace.sh promote

    sudo bash build-tools/install-on-debian-siprec-userspace.sh status

Rollback:

    sudo bash build-tools/install-on-debian-siprec-userspace.sh rollback latest

Emergency recording binary only:

    sudo bash build-tools/fix-recording-bin-on-siprec.sh

## Side-by-side test (does not touch production)

    BIN_DIR="$PWD/release-bins/12.5.1.31-rich-logs/debian" \
      sudo -E bash build-tools/side-by-side-test/run-test.sh install-units
    sudo bash build-tools/side-by-side-test/run-test.sh start
    sudo bash build-tools/side-by-side-test/run-test.sh smoke
    sudo bash build-tools/side-by-side-test/run-test.sh stop
    sudo bash build-tools/side-by-side-test/run-test.sh uninstall-units

## Logs

    sudo journalctl -u rtpengine -u rtpengine-recording -f | grep --line-buffered 'recording '

Full guide: build-tools/CONFLUENCE-12.5.1.31-rich-logs-usage.md
