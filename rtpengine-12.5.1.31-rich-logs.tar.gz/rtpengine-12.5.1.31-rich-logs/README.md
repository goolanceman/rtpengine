# rtpengine 12.5.1.31 rich recording + call QoS logs

See build-tools/CONFLUENCE-12.5.1.31-rich-logs-usage.md

Promote on Debian siprec:
  BIN_DIR="$PWD/release-bins/12.5.1.31-rich-logs/debian" \
    sudo -E bash build-tools/install-on-debian-siprec-userspace.sh promote
