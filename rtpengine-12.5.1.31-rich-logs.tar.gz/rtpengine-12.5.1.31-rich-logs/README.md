# rtpengine 12.5.1.31 rich recording + call QoS logs

See build-tools/BINS.md and build-tools/CONFLUENCE-12.5.1.31-rich-logs-usage.md

Canonical bins (do not use rhel-binaries/ or debian-bins/):
  Debian: release-bins/12.5.1.31-rich-logs/debian/
  RHEL:   release-bins/12.5.1.31-rich-logs/rhel/

Mixer fix (93285198): stream-pin + 1s idle-guard so overlapping SSRCs keep separate slots; MIX_MAX_INPUTS=16.

Promote on Debian siprec:
  BIN_DIR="$PWD/release-bins/12.5.1.31-rich-logs/debian" \
    sudo -E bash build-tools/install-on-debian-siprec-userspace.sh promote

Promote on RHEL lab:
  BIN_DIR="$PWD/release-bins/12.5.1.31-rich-logs/rhel" \
    sudo -E bash build-tools/install-on-debian-siprec-userspace.sh promote
